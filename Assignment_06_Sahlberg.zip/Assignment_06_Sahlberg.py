"""Now that you have reviewed the websites and videos, try to do the following task.
This project is very like the last one, but this time you will place the code you created
for working with your ToDo.txt file into Functions and a Class.
"""

#Data

#create empty dictionary
dToDo = {}
#create empty list table for later
mytest2 = []

#Process

#Create Class
class class1:
#Create functions inside of the class

    #Fucntion to open file read it and put contents into dictionary and List
    def udf_file_dicList():
        """This function opens a file and reads and returns the lines into a list and dictionary"""
        # create empty dictionary
        dToDo = {}
        # create empty list table for later
        mytest2 = []
        Todo = open("C:\\Users\Ian\Documents\Ians\Intro to Python\Module06\Assignment06Files\Todo.txt", "r")
        # split and read file for testing
        for line in Todo:
            line = line.lower().strip()
            # add key and value to dictionary as a set
            (k, v) = line.split(',')
            dToDo[k] = v
            mytest = [k, v]
            mytest2.append(mytest)

        Todo.close()
        return dToDo, mytest2

    #Function to print out the choices
    def udf_choices(mytest2):
        """Print out of the options to select"""
        # loop through dictionary and print the list
        print("The List (Task, Priority)---")

        for x in mytest2:
            print(x)
        print('\n')
        # user options
        print("Menu -")
        print("1) Show current data")
        print("2) Add a new item")
        print("3) Remove an existing item")
        print("4) Save Data to File")
        print("5) Exit Program")

    # fnctn 1, print list
    def opt1(y):
        """Prints out the current list"""
        z = []
        for x in y:
            z += x
        return print(z)

    # fnctn 2
    def opt2(mytest2):
        """Adds a new task, if it already exists then starts over"""
        # ask user for key and value, assign to variables
        k = input("Please enter a task")
        # check if k exists
        for sub in mytest2:
            if sub[0] == k:
                p = print("that task already exists")
                return p
        # append variables to the list
        else:
            v = input("Please enter a priority")
            list = [k, v]
            mytest2 = mytest2.append(list)
            return mytest2

    # Fccntn3
    def opt3(y):
        """Removes an existing item, if it doesnt exist then starts over"""
        deleteIt = input("what is the name of the task?")
        # iterate through list to find value
        for x in y:
            # remove list based on value of nested list
            if x[0] == deleteIt:
                y.remove(x)
                return print(deleteIt, "has been deleted")

        else:
            return print("No task with that name")

    def opt4(y):
        """Saves the List to a file"""
        writeList = open("C:\\Users\Ian\Documents\Ians\Intro to Python\Module06\Assignment06Files\Todo.txt", "w")
        for x in y:
            x = map(str, x)
            line = ",".join(x)
            writeList.write(line)
            writeList.write('\n')
            # close the file to commit changes
        writeList.close()
        return print("it has been done")

    def opt5():
        """Saves the list to a file then quits the program"""
        writeList = open("C:\\Users\Ian\Documents\Ians\Intro to Python\Module06\Assignment06Files\Todo.txt", "w")
        for x in mytest2:
            x = map(str, x)
            line = ",".join(x)
            writeList.write(str(line))
            writeList.write('\n')
        print("it has been done")
        optionbreak = "5"
        writeList.close()
        return optionbreak

#Presentation

#Call the functions
#openfile and translate to dict and list, define the list and dictionary
dToDo, mytest2 = class1.udf_file_dicList()

print("dictionary", dToDo)
#print out choices
class1.udf_choices(mytest2)

#Sentinel
optionbreak = ""
#while user doesnt want to quit
while optionbreak != "5":
    option = input("Please choose an option - 1-5")

    if option == "1":
        class1.opt1(mytest2)
        continue
    elif option == "2":
        class1.opt2(mytest2)
        continue
    elif option == "3":
        class1.opt3(mytest2)
        continue
    elif option == "4":
        class1.opt4(mytest2)
        continue
    elif option == "5":
        class1.opt5()
        break

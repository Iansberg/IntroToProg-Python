"""
Now that you have reviewed the websites and videos, you will create a new script that manages a "ToDo list."
This project is like to the last one, but this time The ToDo file will contain two columns of data (Task, Priority) which you store in a Python dictionary. Each Dictionary will represent one row of data and these rows of data are added to a Python List to create a table of data.
1.	Create a text file called Todo.txt using the following data:
Clean House,low
Pay Bills,high
2.	When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary. (The data will be stored like a row in a table.)
Tip: You can use a for loop to read a single line of text from the file and then place the data into a new dictionary object.
3.	After you get the data in a Python dictionary---
Add the new dictionary “row” into a Python list object (now the data will be managed as a table).
4.	Display the contents of the List to the user.
5.	Allow the user to Add or Remove tasks from the list using numbered choices. Something like this would work:
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
4) Save Data to File
    5) Exit Program
6.	Save the data from the table into the Todo.txt file when the program exits.
Tip: I have provided a starting template to help you organize your code and help with some of the coding. You can use it or create your own file from scratch, but you have a lot of work to do in this module so, you may want to take advantage of the help
"""
#open file
Todo = open("C:\\Users\Ian\Documents\Ians\Intro to Python\Module05\Module05\Todo.txt", "r")

#create empty dictionary
dToDo = {}
#create empty list table for later
mytest2 = []

#split and read file for testing
for line in Todo:
    line = line.lower().strip()
    #add key and value to dictionary as a set
    (k, v) = line.split(',')
    dToDo[k] = v
    mytest = [k,v]
    mytest2.append(mytest)
Todo.close()

#loop through dictionary and print the list
print("The List (Task, Priority)---")

for x in mytest2:
    print(x)
print('\n')
#user options
print("Menu -")
print("1) Show current data")
print("2) Add a new item")
print("3) Remove an existing item")
print("4) Save Data to File")
print("5) Exit Program")


#Sentinel
optionbreak = ""
#while user doesnt want to quit
while optionbreak != "5":
    option = input("Please choose an option - 1-5")
    #if user wants to quit
    if option =="5":
        writeList = open("C:\\Users\Ian\Documents\Ians\Intro to Python\Module05\Module05\Todo.txt", "w")
        for x in mytest2:
            x = map(str, x)
            line = ",".join(x)
            writeList.write(str(line))
            writeList.write('\n')
        print("it has been done")
        optionbreak = "5"
        writeList.close()
    #if 1 then print current list
    if option =="1":
        for x in mytest2:
            print(x)
        continue

    # if 2 then append a new item to List
    if option == "2":
        #ask user for key and value, assign to variables
        k = input("Please enter a task")
        #check if k exists
        for sub in mytest2:
            if sub[0] == k:
                print("that task already exists")
                break
        #append variables to the list
        else:
            v = input("Please enter a priority")
            list = [k,v]
            mytest2.append(list)
            continue

    #if 3 then remove item
    if option =="3":
        #ask for item key
        deleteIt = input("what is the name of the task?")
        #iterate through list to find value
        for x in mytest2:
            #remove list based on value of nested list
            if x[0] == deleteIt:
                mytest2.remove(x)
                print(deleteIt, "has been deleted")
                break
        else:
            print("No task with that name")

    #if 4 then save to file
    if option == "4":
        writeList = open("C:\\Users\Ian\Documents\Ians\Intro to Python\Module05\Module05\Todo.txt", "w")
        for x in mytest2:
            x = map(str, x)
            line = ",".join(x)
            writeList.write(line)
            writeList.write('\n')
        print("it has been done")

        #close the file to commit changes
        writeList.close()


